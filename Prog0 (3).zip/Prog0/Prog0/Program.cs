﻿/*CIS 200-01
Program 0
 File: Program.cs
 This file creates a simple test application class that creates
 an array of LibraryBook objects and tests them.
1-27-20
Grading ID T9749*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Console;

public class Program
{
    // Precondition:  None
    // Postcondition: The LibraryBook class has been tested
    public static void Main(string[] args)
    {
        LibraryBook book1 = new LibraryBook("The Shining", "John P", "NYC",
            2021, "JK012 2A");  // 1st test book
        LibraryBook book2 = new LibraryBook("slick lizard", "Jeff J", "FSU",
            2035, "DG157 8T"); // 2nd test book
        LibraryBook book3 = new LibraryBook("   Gold Member", "Jane L", "Duke",
            2002, "WE578 9B"); // 3rd test book
        LibraryBook book4 = new LibraryBook("Malibu's Most Wanted", "June F", "Texas A&M",
            2003, "RT568 7E");  // 4th test book
        LibraryBook book5 = new LibraryBook("Table Top ", "John K", "LKM",
            2005, "GT856 6Q"); // 5th test book

        LibraryPatron patron = new LibraryPatron("   Ian G", "8855    ");
        LibraryPatron patron0 = new LibraryPatron("Jane P", "7788");
        LibraryPatron patron1 = new LibraryPatron("Tawney S", "6699");


        List<LibraryBook> theBooks = new List<LibraryBook>{ book1, book2, book3, book4, book5 }; // Test array of books

        WriteLine("Original list of books");
        WriteLine("----------------------");
        PrintBooks(theBooks);
        Pause();

        // Make changes
        book1.CheckOut(patron);
        book2.Publisher = "Borrowed Books";
        book2.CheckOut(patron1);
        book3.CheckOut(patron0);
        book4.CallNumber = "AB123 4A";
        book4.CheckOut(patron);
        book5.CheckOut(patron1);


        WriteLine("After changes");
        WriteLine("-------------");
        PrintBooks(theBooks);
        Pause();

        // Return the books
        book1.ReturnToShelf();
        book3.ReturnToShelf();
        book5.ReturnToShelf();

        WriteLine("After returning the books");
        WriteLine("-------------------------");
        PrintBooks(theBooks);
    }

    // Precondition:  None
    // Postcondition: The books have been printed to the console
    public static void PrintBooks(List<LibraryBook> books)
    {
        foreach (LibraryBook b in books)
        {
            WriteLine(b);
            WriteLine();
        }
    }

    // Precondition:  None
    // Postcondition: Pauses program execution until user presses Enter and
    //                then clears the screen
    public static void Pause()
    {
        WriteLine("Press Enter to Continue...");
        ReadLine();

        Clear(); // Clear screen
    }
}
