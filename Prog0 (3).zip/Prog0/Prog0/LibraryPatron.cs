﻿/*CIS 200-01
Program 0
File: LibraryPatron.cs
This file creates a simple LibraryPatron class capable of tracking
the patron's name and ID.
1-27-20
Grading ID T9749*/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


public class LibraryPatron
{
    private string _patronName; // Name of the patron
    private string _patronID;   // ID of the patron

    // Precondition:  None
    // Postcondition: The patron has been initialized with the specified name
    //                and ID
    public LibraryPatron(string name, string id)
    {
        PatronName = name;
        PatronID = id;
    }

    public string PatronName
    {
        // Precondition:  None
        // Postcondition: The patron's name has been returned
        get
        {
            return _patronName;
        }

        // Precondition:  value checked for null or whitespace
        // Postcondition: The patron's name has been set to the specified value, message sent if out of range
        set
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                throw new ArgumentOutOfRangeException(nameof(value), value, $"{nameof(PatronName)} must contain letters.");
            }
            else
            {
                _patronName = value.Trim();
            }
        }
    }

    public string PatronID
    {
        // Precondition:  None
        // Postcondition: The patron's ID has been returned
        get
        {
            return _patronID;
        }

        // Precondition:  value checked for null or whitespace
        // Postcondition: The patron's ID has been set to the specified value, message sent if out of range
        set
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                throw new ArgumentOutOfRangeException(nameof(value), value, $"{nameof(PatronID)} must contain letters.");
            }
            else
            {
                _patronID = value.Trim();
            }
        }
    }

    // Precondition:  None
    // Postcondition: A string is returned presenting the libary patron's data on
    //                separate lines
    public override string ToString()
    {
        string NL = Environment.NewLine; // NewLine shortcut

        return $"Name: {PatronName}{NL}ID: {PatronID}";
    }

}

