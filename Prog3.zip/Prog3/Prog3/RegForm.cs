﻿/*CIS 199-02
This program shows the earliest registration time for University of Louisville students, using parallel arrays to hold time and the first letter of the last name. While loops are incorperated to move from one character to the next to find the correct time and date.
Program 2
11-7-19
Grading ID K3085
Program taken from zip given by instructor for Program 3 use, Andrew Wright*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Prog3
{
    public partial class RegForm : Form
    {
        public RegForm()
        {
            InitializeComponent();
        }

        // Find and display earliest registration time
        private void FindRegTimeBtn_Click(object sender, EventArgs e)
        {
            const string DAY1 = "November 4"; // 1st day of registration
            const string DAY2 = "November 5"; // 2nd day of registration
            const string DAY3 = "November 6"; // 3rd day of registration
            const string DAY4 = "November 7";  // 4th day of registration
            const string DAY5 = "November 8";  // 5th day of registration
            const string DAY6 = "November 11";  // 6th day of registration

            const string TIME1 = "8:30 AM";  // 1st time block
            const string TIME2 = "10:00 AM"; // 2nd time block
            const string TIME3 = "11:30 AM"; // 3rd time block
            const string TIME4 = "2:00 PM";  // 4th time block
            const string TIME5 = "4:00 PM";  // 5th time block

            const float SOPHOMORE = 30; // Hours needed to be sophomore
            const float JUNIOR = 60;    // Hours needed to be junior
            const float SENIOR = 90;    // Hours needed to be senior

            string lastNameStr;         // Entered last name
            char lastNameLetterCh;      // First letter of last name, as char
            string dateStr = "Error";   // Holds date of registration
            string timeStr = "Error";   // Holds time of registration
            float creditHours;          // Previously earned credit hours
            bool isUpperClass;          // Upperclass or not?
            bool found = false;//hold value if index is found or not
            int index;//hold value of index for loop 

            lastNameStr = lastNameTxt.Text;// get lastname from user input
            if (lastNameStr.Length > 0) // Empty string?
            {
                lastNameLetterCh = lastNameStr[0];   // First char of last name
                lastNameLetterCh = char.ToUpper(lastNameLetterCh); // Ensure upper case

                string[] time = { TIME3, TIME4, TIME5, TIME1, TIME2 };  // Lower limits of WPM ranges
                char[] lastNameLetter = { 'A', 'E', 'J', 'P', 'T' }; // Possible grades

                string[] timeSF = { TIME5, TIME1, TIME2, TIME3, TIME4, TIME5, TIME1, TIME2, TIME3, TIME4 };  // Lower limits of WPM ranges
                char[] lastNameLetterSF = { 'A', 'C', 'E', 'G', 'J', 'M', 'P', 'R', 'T', 'W' }; // Possible grades

                if (float.TryParse(creditHoursTxt.Text, out creditHours) && creditHours >= 0)//use credit hours to find the correct date and time for user to register
                {
                    if (char.IsLetter(lastNameLetterCh)) // Is it a letter?
                    {
                        isUpperClass = (creditHours >= JUNIOR);//is the credit hours enough to be considered 

                        // Juniors and Seniors share same schedule but different days
                        if (isUpperClass)
                        {
                            if (creditHours >= SENIOR)
                                dateStr = DAY1;
                            else // Must be juniors
                                dateStr = DAY2;

                            index = lastNameLetter.Length - 1; // Start from end of array, loop to find the correct date and time, return time to user
                            while (index >= 0 && !found)
                            {
                                if (lastNameLetterCh >= lastNameLetter[index])
                                {// Found it!
                                    found = true;
                                }
                                else
                                    --index;

                                if (found)
                                {
                                    timeStr = time[index];//use index to relate to the time for user
                                }
                            }
                        }
                        // Sophomores and Freshmen
                        else// Must be soph/fresh
                        {
                            if (creditHours >= SOPHOMORE)
                            {
                                // A-B, P-Z on day one
                                if ((lastNameLetterCh <= 'B') ||  // <= B
                                    (lastNameLetterCh >= 'P'))    // >= P
                                    dateStr = DAY3;
                                else // All other letters on next day
                                    dateStr = DAY4;
                            }
                            else // must be freshman
                            {
                                // A-B, P-Z on day one
                                if ((lastNameLetterCh <= 'B') ||  // <= B
                                    (lastNameLetterCh >= 'P'))    // >= P
                                    dateStr = DAY5;
                                else // All other letters on next day
                                    dateStr = DAY6;
                            }
                            index = lastNameLetterSF.Length - 1; // Start from end of array,loop to find the correct date and time, return time to user
                            while (index >= 0 && !found)
                            {
                                if (lastNameLetterCh >= lastNameLetterSF[index])
                                {// Found it!
                                    found = true;
                                }
                                else
                                    --index;

                                if (found)
                                {
                                    timeStr = timeSF[index];//use index to relate to the time for user
                                }

                            }
                        }

                            // Output results
                            dateTimeLbl.Text = $"{dateStr} at {timeStr}";
                        }
                        else // Not A-Z
                            MessageBox.Show("Make sure last name starts with a letter!");
                    }
                    else
                        MessageBox.Show("Enter a valid number of credit hours!");
                }
                else // Empty textbox
                    MessageBox.Show("Please enter last name!");
            }
        }
    }
