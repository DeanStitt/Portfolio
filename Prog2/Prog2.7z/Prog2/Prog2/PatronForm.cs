﻿/*CIS 200-01
Program 2
File: PatronForm.cs
This file creates the actions for the parton form. 
3/8/20
Grading ID T9749*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class PatronForm : Form
    {
        public PatronForm()//creates actions for the patron form 
        {
            InitializeComponent();
        }

        internal String PatronName
        {
            get
            {
                return patronNameTxt.Text;//pre none post get the name
            }

            set
            {
                patronNameTxt.Text = value;//pre none post set the name
            }
        }
        internal String PatronID
        {
            get
            {
                return patronIdTxt.Text; //pre none post get the Id
            }

            set
            {
                patronIdTxt.Text = value;// pre none post set the Id
            }
        }
        private void cancelBtn_MouseDown(object sender, MouseEventArgs e)// pre used to cancel post cancel the window 
        {
            if (e.Button == MouseButtons.Left)
                this.DialogResult = DialogResult.Cancel;
        }

        private void patronNameTxt_Validating(object sender, CancelEventArgs e)//pre user entered data post data validated 
        {
            if (string.IsNullOrWhiteSpace(patronIdTxt.Text))
            {
                e.Cancel = true;
                patronNameTxt.SelectAll();
                errorProvider1.SetError(patronNameTxt, "Must provide Name");
            }
        }
        private void patronNameTxt_Validated(object sender, EventArgs e)//pre user entered data post data validated 
        {
            errorProvider2.SetError(patronNameTxt, "");
        }
        private void patronIdTxt_Validating(object sender, CancelEventArgs e)//pre user entered data post data validated 
        {
            e.Cancel = true;
            patronNameTxt.SelectAll();
            errorProvider1.SetError(patronIdTxt, "Must provide Name");
        }

        private void patronIdTxt_Validated_1(object sender, EventArgs e)//pre user entered data post data validated 
        {
            errorProvider1.SetError(patronIdTxt, "");
        }
    }
}
