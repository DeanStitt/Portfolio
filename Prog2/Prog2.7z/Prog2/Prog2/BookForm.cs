﻿/*CIS 200-01
Program 2
File: BookForm.cs
This file creates the actions for the book form. 
3/8/20
Grading ID T9749*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class BookForm : Form
    {
        public BookForm()//form used to enter the data for the book 
        {
            InitializeComponent();
        }

        private void titleTxt_Validated(object sender, EventArgs e)//Pre user entered data post data validated 
        {
            Control control;

            if (sender is Control)
            {
                control = sender as Control;

                errorProvider1.SetError(control, "");
            }
            else
                throw new ArgumentException("Control must be sent");
        }

        private void publisherTxt_Validated(object sender, EventArgs e)//Pre user entered data post data validated 
        {
            Control control;

            if (sender is Control)
            {
                control = sender as Control;

                errorProvider2.SetError(control, "");
            }
            else
                throw new ArgumentException("Control must be sent");
        }

        private void copyRightTxt_Validated(object sender, EventArgs e)//Pre user entered data post data validated 
        {
            Control control;

            if (sender is Control)
            {
                control = sender as Control;

                errorProvider1.SetError(control, "");
            }
            else
                throw new ArgumentException("Control must be sent");
        }

        private void loanPeriodTxt_Validated(object sender, EventArgs e)//Pre user entered data post data validated 
        {
            Control control;

            if (sender is Control)
            {
                control = sender as Control;

                errorProvider1.SetError(control, "");
            }
            else
                throw new ArgumentException("Control must be sent");
        }

        private void callNumberTxt_Validated(object sender, EventArgs e)//Pre user entered data post data validated 
        {
            Control control;

            if (sender is Control)
            {
                control = sender as Control;

                errorProvider1.SetError(control, "");
            }
            else
                throw new ArgumentException("Control must be sent");
        }

        private void authorTxt_Validated(object sender, EventArgs e)//Pre user entered data post data validated 
        {
            Control control;

            if (sender is Control)
            {
                control = sender as Control;

                errorProvider1.SetError(control, "");
            }
            else
                throw new ArgumentException("Control must be sent");
        }
    }
}
