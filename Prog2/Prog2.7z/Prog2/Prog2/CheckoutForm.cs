﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class checkoutForm : Form
    {
        private List<LibraryItem> _items;
        private List<LibraryPatron> _patron;


        public checkoutForm(List<LibraryItem> itemList, List<LibraryPatron> patronList)
        {
            InitializeComponent();

            _items = itemList;
            _patron = patronList;

            foreach (LibraryItem item in _items)
                itemBox.Items.Add($"{item.Title}, {item.CallNumber}");
            foreach (LibraryPatron patron in _patron)
                patronBox.Items.Add($"{patron.PatronName}, {patron.PatronID}");
        }

        internal int ItemIndex;
    }
}
