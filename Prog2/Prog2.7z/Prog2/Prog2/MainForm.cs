﻿/*CIS 200-01
Program 2
File: MainForm.cs
This file creates the actions for the form on the main page of the GUI.
3/8/20
Grading ID T9749*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class MainForm : Form
    {
        private Library _lib; //the library 
        public MainForm()// main form used to intake data used in other forms
        {
            InitializeComponent();

            //Test data
            _lib = new Library(); // create the library

            List<LibraryItem> Lb = new List<LibraryItem>(); // Test array of books

            _lib.AddLibraryJournal("The Shining", "John P", 2020, 7,
                "2512339696", 15, 10, "Fiction", "Jim Book");
            _lib.AddLibraryJournal("The Tempature", "Smith F", 2040, 9,
    "2512332356", 25, 41, "Fiction", "Tom Wall");
            this._lib.AddLibraryMagazine("Welcome Home", "The Times", 2020, 26, "2534562847", 5, 2);
            _lib.AddLibraryMagazine("Welcome Home", "NYC", 2020, 26, "2534562847", 7, 3);
            _lib.AddLibraryBook("Home", "The Times", 2120, 15, "12546382546", "Tom riddle");
            _lib.AddLibraryBook("Welcome Back", "The Page", 2030, 16, "12548657958", "Steven Snake");
            _lib.AddLibraryMovie("Tommorrow", "Printers Pub", 2020, 10, "Tom Clancy", 2.50, "15245298564", LibraryMediaItem.MediaType.BLURAY, LibraryMovie.MPAARatings.PG);
            _lib.AddLibraryMovie("Simon Says", "Loins Gate", 2010, 8, "Fiddle Riddle", 1.30, "5625478524", LibraryMediaItem.MediaType.DVD, LibraryMovie.MPAARatings.PG13);
            _lib.AddLibraryMusic("Say same", "Greens", 2011, 7, "46434543155", .20, "Sam Unt", LibraryMediaItem.MediaType.CD, 12);
            _lib.AddLibraryMusic("Ting tock", "Blend", 2012, 7, "13543531318", .50, "Arial Two", LibraryMediaItem.MediaType.VINYL, 5);
        }

        private void aboutToolStripMenuItem1_Click(object sender, EventArgs e)//pre user clicks the about tab, post the user can view the data 
        {
            string NL = Environment.NewLine;

            MessageBox.Show($"CIS 200-01\n Program 2 \nFile: MainForm.cs\n This file creates the actions for the form on the main page of the GUI.\n 3 / 8 / 20 \n Grading ID T9749 ");
        }

        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)//pre user clicks the exit tab, post the user exits
        {
            this.Close();
        }


        private void patronToolStripMenuItem_Click(object sender, EventArgs e)//pre user clicks the patron tab, post user can enter patron information 
        {
            PatronForm patronForm = new PatronForm();

            DialogResult result = patronForm.ShowDialog();

            if (result == DialogResult.OK)//validate data
            {
                _lib.AddPatron(patronForm.PatronName, patronForm.PatronID);
            }
            patronForm.Dispose();
        }

        private void bookToolStripMenuItem_Click(object sender, EventArgs e)//pre user clicks the book tab, post the user can enter book information 
        {
            BookForm bookForm = new BookForm();

            DialogResult result = bookForm.ShowDialog();
            if (result == DialogResult.OK)
                try
                {
                    _lib.AddLibraryBook(bookForm.ItemTitle, bookForm.ItemPublisher, int.Parse(bookForm.ItemCopyrightYear), int.Parse(bookForm.ItemLoanPeriod), bookForm.ItemCallNumber, bookForm.ItemAuthor);
                }

                catch (FormatException)
                {
                    MessageBox.Show("validation error");
                }
        }

        private void checkoutToolStripMenuItem_Click(object sender, EventArgs e)//pre user clicks the checkout tab, post the user can checkout items
        {
            List<LibraryItem> items;
            List<LibraryPatron> patrons;

            items = _lib.GetItemsList();
            patrons = _lib.GetPatronsList();

            if ((items.Count() == 0) || (patrons.Count() == 0))
            {
                MessageBox.Show("Patrons and Items are needed.");
            }
            else
            {
                checkoutForm CheckoutForm = new checkoutForm(items, patrons);
                DialogResult result = checkoutForm.ShowDialog();

                if (result == DialogResult.OK)
                {
                    _libCheckout(checkoutForm.ItemIndex, checkoutForm.PatronIndex);
                }

                CheckoutForm.Dispose;
            }

            var checkedOutItems =
                from item in items
                where item.IsCheckedOut()
                select item;

            reportTxt.Text = $"Checked out items - {checkedOutItems.Count}";

            foreach (LibraryItem p in checkedOutItems)
                reportTxt.AppendText($"{p}{NL}{NL}");
        }
    }
}

