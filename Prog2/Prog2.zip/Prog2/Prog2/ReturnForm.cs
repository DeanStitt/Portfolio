﻿/*CIS 200-01
Program 2
File: ReturnForm.cs
This file creates the actions for the return form. 
3/8/20
Grading ID T9749*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class ReturnForm : Form
    {
        private List<LibraryItem> _items;
        private List<int> checkedOutIndices;
        public ReturnForm(List<LibraryItem> itemList)//pre form opened by user post items returned in combo box
        {
            InitializeComponent();
            _items = itemList;
            checkedOutIndices = new List<int>();

        }

        private void ReturnForm_Load(object sender, EventArgs e)// pre form loaded and items chosen to be returned post items returned 
        {
            for (int i = 0; i < _items.Count; ++i)
            {
                if(_items[i].IsCheckedOut())
                {
                    box.Items.Add($"{_items[i].Title}, {_items[i].CallNumber}");
                }
            }
        }

    }
}
