﻿// Lab 2
// CIS 199-XX
// Due: 9/15/2019
// By: Andrew L. Wright (students use Grading ID)

// This program prompts the user for the price of a meal
// and then calculates 3 different tip amounts, 15%,
// 18%, and 20%.

// Solution A
// This solution leaves the tip rates hard coded on the form in the labels, so if change
// the constants below, be sure to update the form's labels.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Lab2
{
    public partial class TipForm : Form
    {
        public TipForm()
        {
            InitializeComponent();
        }

        // Calculate and display tips
        private void calcTipBtn_Click(object sender, EventArgs e)
        {
            const decimal TIPRATE1 = 0.15m; // 15% rate
            const decimal TIPRATE2 = 0.18m; // 18% rate
            const decimal TIPRATE3 = 0.20m; // 20% rate

            decimal price; // Price of meal
            decimal tip1;  // Tip amount for rate 1
            decimal tip2;  // Tip amount for rate 2
            decimal tip3;  // Tip amount for rate 3

            // Convert input into decimal
            price = decimal.Parse(priceTxt.Text);

            // Calculate tip amounts
            tip1 = TIPRATE1 * price;
            tip2 = TIPRATE2 * price;
            tip3 = TIPRATE3 * price;

            // Display tip amounts
            tip1Lbl.Text = $"{tip1:C}";
            tip2Lbl.Text = $"{tip2:C}";
            tip3Lbl.Text = $"{tip3:C}";
        }
    }
}
