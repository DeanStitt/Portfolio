﻿/*CIS 199-02
This program shows the earliest registration time for University of Louisville students.
Program 2
10-16-19
Grading ID K3085*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_2
{
    public partial class Program2 : Form
    {
        public Program2()
        {
            InitializeComponent();
        }

        private void Calculate_Click(object sender, EventArgs e)
        {
            char lastName1;//variable for computing lastname entered
            char lastName;// variable for lastname to be lowercase
            float creditHour;//variable for hours 
            const int senior = 90;//variable for senior hours
            const int junior = 60;//variable for junior hours
            const int sophomores = 30;//variable for sophmores hours
            const string seniorDate = "Nov 4, 2019";//variable for senior date
            const string juniorDate = "Nov 5, 2019";//variable for junior date
            const string sophmoresDate1 = "Nov 6, 2019";//variable for sophomores date
            const string sophmoresDate2 = "Nov 7, 2019";//variable for sophomores date2
            const string freshmanDate = "Nov 8, 2019";//variable for freshman date
            const string freshmanDate2 = "Nov 11, 2019";//variable for freshman date2
            const string time1 = "11:30am";//variable for time1
            const string time2 = "2:00pm";//variable for  time2
            const string time3 = "4:00pm";//variable for time3 
            const string time4 = "8:30am";//variable for time4
            const string time5 = "10:00am";//variable for time5
            string time;//variable for time
            string date;//variable for date

            //90+ credit hours is a senior, 60+ credit hours is a junior, 30+ credit hours is a sophomore, less than that is a freshman.
            if (char.TryParse(lastNameT.Text, out lastName))//cal student year and registration date/time
            {
                lastName1 = char.ToLower(lastName);
                if (float.TryParse(credithourT.Text, out creditHour))
                {
                    if (creditHour >= senior)
                    {
                        date = seniorDate;
                        if (lastName1 <= 'd')
                        {
                            time = time1;
                        }
                        else if (lastName1 <= 'i')
                        {
                            time = time2;
                        }
                        else if (lastName1 <= 'o')
                        {
                            time = time3;
                        }
                        else if (lastName1 <= 's')
                        {
                            time = time4;
                        }
                        else
                        {
                            time = time5;
                        }
                        MessageBox.Show($"Your priority registration is {date} at {time}");
                    }
                    else if (creditHour >= junior)
                    {
                        date = juniorDate;
                        if (lastName1 <= 'd')
                        {
                            time = time1;
                        }
                        else if (lastName1 <= 'i')
                        {
                            time = time2;
                        }
                        else if (lastName1 <= 'o')
                        {
                            time = time3;
                        }
                        else if (lastName1 <= 's')
                        {
                            time = time4;
                        }
                        else
                        {
                            time = time5;
                        }
                        MessageBox.Show($"Your priority registration is {date} at {time}");
                    }

                    else if (creditHour >= sophomores)
                    {
                        if (lastName1 >= 'c' && lastName1 <= 'o')
                        {
                            date = sophmoresDate2;
                            if (lastName1 <= 'b')

                            {

                                time = time3;
                            }
                            else if (lastName1 <= 'd')
                            {

                                time = time4;
                            }
                            else if (lastName1 <= 'f')
                            {

                                time = time5;
                            }
                            else if (lastName1 <= 'i')
                            {

                                time = time1;
                            }
                            else if (lastName1 <= 'l')
                            {


                                time = time2;
                            }
                            else if (lastName1 <= 'o')
                            {

                                time = time3;
                            }
                            else if (lastName1 <= 'q')
                            {

                                time = time4;
                            }
                            else if (lastName1 <= 'v')
                            {
                                time = time1;
                            }
                            else
                            {

                                time = time2;
                            }
                            MessageBox.Show($"Your priority registration is {date} at {time}");
                        }
                        else
                        {
                            date = sophmoresDate1;
                            if (lastName1 <= 'b')

                            {

                                time = time3;
                            }
                            else if (lastName1 <= 'd')
                            {

                                time = time4;
                            }
                            else if (lastName1 <= 'f')
                            {

                                time = time5;
                            }
                            else if (lastName1 <= 'i')
                            {

                                time = time1;
                            }
                            else if (lastName1 <= 'l')
                            {


                                time = time2;
                            }
                            else if (lastName1 <= 'o')
                            {

                                time = time3;
                            }
                            else if (lastName1 <= 'q')
                            {

                                time = time4;
                            }
                            else if (lastName1 <= 's')
                            {
                                time = time5;
                            }

                            else if (lastName1 <= 'v')
                            {
                                time = time1;
                            }
                            else
                            {

                                time = time2;
                            }
                            MessageBox.Show($"Your priority registration is {date} at {time}");
                        }

                    }
                    else if (creditHour < sophomores)
                    {
           
                    if (lastName1 >= 'c' && lastName1 <= 'o')
                    {
                        date = freshmanDate2;
                        if (lastName1 <= 'b')
                        {

                            time = time3;
                        }
                        else if (lastName1 <= 'd')
                        {

                            time = time4;
                        }
                        else if (lastName1 <= 'f')
                        {

                            time = time5;

                        }
                        else if (lastName1 <= 'i')
                        {

                            time = time1;
                        }
                        else if (lastName1 <= 'l')
                        {

                            time = time2;
                        }
                        else if (lastName1 <= 'o')
                        {

                            time = time3;
                        }
                        else if (lastName1 <= 'q')
                        {

                            time = time4;
                        }
                        else if (lastName1 <= 's')
                        {
                            time = time5;
                        }
                        else if (lastName1 <= 'v')
                        {

                            time = time1;
                        }
                        else
                        {

                            time = time2;
                        }
                        MessageBox.Show($"Your priority registration is {date} at {time}");

                        }
                        else
                        {
                            date = freshmanDate;

                            if (lastName1 <= 'b')
                            {

                                time = time3;
                            }
                            else if (lastName1 <= 'd')
                            {

                                time = time4;
                            }
                            else if (lastName1 <= 'f')
                            {

                                time = time5;

                            }
                            else if (lastName1 <= 'i')
                            {

                                time = time1;
                            }
                            else if (lastName1 <= 'l')
                            {

                                time = time2;
                            }
                            else if (lastName1 <= 'o')
                            {

                                time = time3;
                            }
                            else if (lastName1 <= 'q')
                            {

                                time = time4;
                            }
                            else if (lastName1 <= 's')
                            {
                                time = time5;
                            }
                            else if (lastName1 <= 'v')
                            {

                                time = time1;
                            }
                            else
                            {

                                time = time2;
                            }
                            MessageBox.Show($"Your priority registration is {date} at {time}");

                        }
                    }
                }
            }
        }
    }
}

