﻿namespace Program_2
{
    partial class Program2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lastNameT = new System.Windows.Forms.TextBox();
            this.lastName = new System.Windows.Forms.Label();
            this.Calculate = new System.Windows.Forms.Button();
            this.credithourT = new System.Windows.Forms.TextBox();
            this.creditHours = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lastNameT
            // 
            this.lastNameT.Location = new System.Drawing.Point(292, 49);
            this.lastNameT.Margin = new System.Windows.Forms.Padding(2);
            this.lastNameT.Name = "lastNameT";
            this.lastNameT.Size = new System.Drawing.Size(76, 20);
            this.lastNameT.TabIndex = 0;
            // 
            // lastName
            // 
            this.lastName.AutoSize = true;
            this.lastName.Location = new System.Drawing.Point(76, 49);
            this.lastName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lastName.Name = "lastName";
            this.lastName.Size = new System.Drawing.Size(176, 13);
            this.lastName.TabIndex = 1;
            this.lastName.Text = "Enter the 1st letter of your last name";
            // 
            // Calculate
            // 
            this.Calculate.Location = new System.Drawing.Point(292, 137);
            this.Calculate.Margin = new System.Windows.Forms.Padding(2);
            this.Calculate.Name = "Calculate";
            this.Calculate.Size = new System.Drawing.Size(74, 19);
            this.Calculate.TabIndex = 2;
            this.Calculate.Text = "Calculate";
            this.Calculate.UseVisualStyleBackColor = true;
            this.Calculate.Click += new System.EventHandler(this.Calculate_Click);
            // 
            // credithourT
            // 
            this.credithourT.Location = new System.Drawing.Point(292, 87);
            this.credithourT.Margin = new System.Windows.Forms.Padding(2);
            this.credithourT.Name = "credithourT";
            this.credithourT.Size = new System.Drawing.Size(76, 20);
            this.credithourT.TabIndex = 3;
            // 
            // creditHours
            // 
            this.creditHours.AutoSize = true;
            this.creditHours.Location = new System.Drawing.Point(109, 87);
            this.creditHours.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.creditHours.Name = "creditHours";
            this.creditHours.Size = new System.Drawing.Size(149, 13);
            this.creditHours.TabIndex = 4;
            this.creditHours.Text = "Enter your current credit hours";
            // 
            // Program2
            // 
            this.AcceptButton = this.Calculate;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(434, 211);
            this.Controls.Add(this.creditHours);
            this.Controls.Add(this.credithourT);
            this.Controls.Add(this.Calculate);
            this.Controls.Add(this.lastName);
            this.Controls.Add(this.lastNameT);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Program2";
            this.Text = "Program 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox lastNameT;
        private System.Windows.Forms.Label lastName;
        private System.Windows.Forms.Button Calculate;
        private System.Windows.Forms.TextBox credithourT;
        private System.Windows.Forms.Label creditHours;
    }
}

